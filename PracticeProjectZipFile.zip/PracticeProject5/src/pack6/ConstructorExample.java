package pack6;

class Person{
	private String name;
	private int age;
	
	//default constructor
	public Person() {
		name="unknown";
		age=0;	
	}
	//parameterised constructor
	public Person(String name, int age) {
		this.name=name;
		this.age=age;
	}
	//overloaded constructor
	public Person(String name) {
		this.name=name;
		this.age=0;  //default age
	}
	
	public String getName() {
		return name;
	}
	
	public int getAge() {
		return age;
	}
}

public class ConstructorExample {

	public static void main(String[] args) {
		Person person1= new Person();
		Person person2= new Person("John",30);
		Person person3= new Person("Bob");
		
		System.out.println("Person 1: Name -"+ person1.getName()+" ,age -" +person1.getAge());
		System.out.println("Person 1: Name -"+ person2.getName()+" ,age -" +person2.getAge());
		System.out.println("Person 1: Name -"+ person3.getName()+" ,age -" +person3.getAge());
	}

}
