package Pack4;

public class AccessModifiersExample {
	public int variable1=10;
	private int variable2=20;
	protected int variable3=30;
	int variable4=40;
	
	public void publicMethodExample() {
		System.out.println("This is a public method");
	}
	
    private void privateMethodExample() {
    	System.out.println("This is a private method");
		
	}
    private void protectedMethodExample() {
    	System.out.println("This is a protected method");
		
	}
    void defaultMethod() {
    	System.out.println("This is a default method");
    	
    }
    	
	
	public static void main(String[] args) {
		AccessModifiersExample AME = new AccessModifiersExample();
		
		//accessing variable and method in same class
		System.out.println(AME.variable1);
		System.out.println(AME.variable2);
		System.out.println(AME.variable3);
		System.out.println(AME.variable4);
		
		AME.privateMethodExample();
		AME.privateMethodExample();
		AME.protectedMethodExample();
	}

}
