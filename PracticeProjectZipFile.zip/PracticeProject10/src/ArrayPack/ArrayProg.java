package ArrayPack;

public class ArrayProg {
	public static void main(String[] args) {

		//single-dimensional array
		int x[]= {10,20,30,40,50};
		for(int i=0;i<x.length;i++) {
		System.out.println("Elements of array x: "+x[i]);
		}


		//multidimensional array
		int[][] y = {
		            {2, 4, 6, 8}, 
		            {3, 6, 9} };
		      
		      System.out.println("\nLength of row 1: " + y[0].length);
		      }

}
