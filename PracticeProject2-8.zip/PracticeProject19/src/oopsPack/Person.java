package oopsPack;


//Encapsualtion Example
public class Person {
    // Private instance variables (attributes)
    private String name;
    private int age;

    // Constructor to initialize the object
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    // Getter method for the name attribute
    public String getName() {
        return name;
    }

    // Setter method for the name attribute
    public void setName(String name) {
        this.name = name;
    }

    // Getter method for the age attribute
    public int getAge() {
        return age;
    }

    // Setter method for the age attribute
    public void setAge(int age) {
        if (age >= 0) {
            this.age = age;
        } else {
            System.out.println("Age cannot be negative.");
        }
    }

    // Display method to show the person's details
    public void displayDetails() {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
    }

    public static void main(String[] args) {
        // Create a Person object
        Person person = new Person("John", 30);

        // Access and display the details using getter methods
        System.out.println("Initial Details:");
        person.displayDetails();

        // Update the details using setter methods
        person.setName("Alice");
        person.setAge(-25); // Trying to set a negative age

        // Access and display the updated details
        System.out.println("\nUpdated Details:");
        person.displayDetails();
    }
}
