package oopsPack;


//Abstract class
abstract class Shape {
 // Abstract method (no method body)
 public abstract void draw();
}

//Concrete subclass 1
class Circle extends Shape {
 @Override
 public void draw() {
     System.out.println("Drawing a Circle");
 }
}

//Concrete subclass 2
class Rectangle extends Shape {
 @Override
 public void draw() {
     System.out.println("Drawing a Rectangle");
 }
}

public class AbstractionDemo {
 public static void main(String[] args) {
     // Creating objects of concrete subclasses
     Shape circle = new Circle();
     Shape rectangle = new Rectangle();

     // Calling the abstract method
     circle.draw();
     rectangle.draw();
 }
}
