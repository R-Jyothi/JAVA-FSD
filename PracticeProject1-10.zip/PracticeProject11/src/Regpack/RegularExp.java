package Regpack;
import java.util.regex.*;

public class RegularExp {
	//example for phoneverifier
	public static void main(String[] args) {
        // Define the regular expression pattern for a US phone number in ###-###-#### format
        String phonePattern = "^[2-9]\\d{2}-\\d{3}-\\d{4}$";

        // Test phone numbers
        String[] testPhoneNumbers = {
            "999-456-9999",
            "555-5555",
            "1234-567-8901",
            "800-123-4567",
            "123-456-789a"
        };

        // Create a Pattern object
        Pattern pattern = Pattern.compile(phonePattern);

        // check whether phone number pattern is match or not
        for (String phoneNumber : testPhoneNumbers) {
            Matcher matcher = pattern.matcher(phoneNumber);
            boolean isValid = matcher.matches();
            System.out.println(phoneNumber + " is valid: " + isValid);
        }
    }

}
