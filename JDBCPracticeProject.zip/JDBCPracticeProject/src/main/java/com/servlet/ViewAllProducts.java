package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pack.DBConnection;

/**
 * Servlet implementation class ViewAllProducts
 */
@WebServlet("/ViewAllProducts")
public class ViewAllProducts extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ViewAllProducts() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		

		out.print("<p style='text-align: center;width:100%'>");
		out.print("<a href='AddProduct.html'>New Product</a>");
		out.print("&nbsp;&nbsp;|&nbsp;&nbsp;");
		out.print("<a href='Search.html'>Search Product</a>");
		out.print("</p><hr />");	
		try
		{
			Connection conObj = DBConnection.getConnection();
			PreparedStatement psObj = conObj.prepareStatement("select * from eproduct");
			ResultSet  rs = psObj.executeQuery();
			out.print("<table width='100%' border='1'>");
			out.print("<tr><th>Product id</th><th>Product Name</th><th>Product Price</th><th>Product Place</th></tr>");
			while(rs.next())
			{
				out.print("<tr>");
				out.print("<td>" + rs.getInt("pid") + "</td>");
				out.print("<td>" + rs.getString("pname") + "</td>");
				out.print("<td>" + rs.getString("price") + "</td>");
				out.print("<td>" + rs.getString("place") + "</td>");
				out.print("</tr>");
			}
			out.print("</table>");
		}
		catch(Exception ex)
		{
			System.out.println(ex);
		}
	}

}
