package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pack.DBConnection;

/**
 * Servlet implementation class SearchProduct
 */
@WebServlet("/SearchProduct")
public class SearchProduct extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchProduct() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String pid = request.getParameter("txtpid");
		try
		{
			Connection conObj = DBConnection.getConnection();
			PreparedStatement psObj = conObj.prepareStatement("Select * from eproduct where pid=?");
			psObj.setString(1, pid);
			ResultSet  rs = psObj.executeQuery();
			if(rs.next())
			{
				out.print("<table width='100%' border='1'>");
				out.print("<tr><th>Product id</th><th>Product Name</th><th>Product Price</th><th>Product Place</th></tr>");
				out.print("<tr>");
				out.print("<td>" + rs.getInt("pid") + "</td>");
				out.print("<td>" + rs.getString("pname") + "</td>");
				out.print("<td>" + rs.getString("price") + "</td>");
				out.print("<td>" + rs.getString("place") + "</td>");
				out.print("</tr>");
				out.print("</table>");
			}
			else
			{
				out.print("<table width='100%' border='1'>");
				out.print("<tr><td><h2>Product Not Found</h2></td</tr>");
				out.print("</table>");
			}
			out.print("<p style='text-align:center;width:100%'>");
			out.print("<h3><a href='Search.html'>Back</a></h3></p>");
		}
		catch(Exception ex)
		{
			System.out.println(ex);
		}
		
		
	}
	

}
