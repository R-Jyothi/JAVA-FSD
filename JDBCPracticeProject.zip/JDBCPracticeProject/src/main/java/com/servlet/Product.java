package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pack.DBConnection;

import java.sql.*;
import java.sql.Connection;


@WebServlet("/Product")
public class Product extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    public Product() {
        super();
  
    }
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();	
		String pname = request.getParameter("txtpname");
		String price = request.getParameter("txtprice");
		String place = request.getParameter("txtplace");		
		try
		{
			Connection conObj = DBConnection.getConnection();
			PreparedStatement  ps = conObj.prepareStatement("Insert into eproduct(pname,price,place) values(?,?,?)");
			ps.setString(1, pname);
			ps.setString(2, price);
			ps.setString(3, place);
            int res = ps.executeUpdate();
			if(res>=1)
				response.sendRedirect("ViewAllProducts");
			
		}
	
		catch(Exception ex) {
			System.out.println(ex);
		}


	}

}
