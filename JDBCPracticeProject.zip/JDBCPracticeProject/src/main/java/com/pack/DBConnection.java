package com.pack;

import java.sql.*;
import java.sql.Connection;
public class DBConnection {
	public static Connection  getConnection()
	{
		Connection con = null;
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con  = DriverManager.getConnection("jdbc:mysql://localhost:3306/PROJECT", "root", "Technology@2023");
			
		}
		catch(Exception ex)
		{
			System.out.println(ex);
		}
		return con;


	}

}
