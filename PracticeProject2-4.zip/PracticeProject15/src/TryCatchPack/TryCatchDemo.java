package TryCatchPack;
import java.util.Scanner;

public class TryCatchDemo {

	public static void main(String[] args) {
 
        Scanner scanner = new Scanner(System.in);
        
        try 
        {
           // Prompt the user for input
            System.out.print("Enter a number: ");
            int num = Integer.parseInt(scanner.nextLine());

         // Attempt to divide 10 by the user's input
            int result = 10 / num;

                // Display the result
            System.out.println("Result: " + result);
        } catch (ArithmeticException e) 
        {
        	
            // Catch and handle the arithmetic exception (division by zero)
            System.out.println("Error: Division by zero is not allowed.");
        } catch (NumberFormatException e) 
        {
        	
            // Catch and handle the number format exception (invalid input)
            System.out.println("Error: Invalid input. Please enter a valid number.");
        } finally 
        {
        	
            // Close the scanner 
            scanner.close();
        }

	}

}
