package com.simplilearn.demo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FillRegisterForm {
	public static void main(String[] args) {
		//step:1 declare the path
				String path="C:\\Phase5Installation\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe";
				
				//step:2 set system property
				System.setProperty("webdriver.chrome.driver", path);
				
				//step:3 give base url
				String url="https://www.shine.com/registration/";
				
				//step:4 initiate webdriver
				WebDriver driver= new ChromeDriver();
				
				driver.get(url);
				
				
				WebElement name= driver.findElement(By.id("id_name"));
				name.sendKeys("Naga Jyothi");
				

				WebElement email= driver.findElement(By.id("id_email"));	
				email.sendKeys("jyothi7989@gmail.com");
				
				WebElement phone= driver.findElement(By.id("id_cell_phone"));				
				phone.sendKeys("7989798979");
				
				WebElement password=driver.findElement(By.id("id_password"));
				password.sendKeys("Nagajyothi@12345");
				
				
				WebElement Check= driver.findElement(By.id("id_privacy"));
				

				WebElement Continue= driver.findElement(By.id("registerButton"));
				Continue.click();
			
				
				
	}
}
