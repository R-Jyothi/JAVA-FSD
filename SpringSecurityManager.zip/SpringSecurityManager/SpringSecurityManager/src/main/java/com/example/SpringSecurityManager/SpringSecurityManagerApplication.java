package com.example.SpringSecurityManager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityManagerApplication.class, args);
	}

}
