package com.example.SpringSecurityManager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
