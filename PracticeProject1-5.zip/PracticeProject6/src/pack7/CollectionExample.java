package pack7;

public class CollectionExample {
	  public static void main(String[] args) {
	        // Create an array to store integers
	        int[] numbers = new int[5];

	        // Add elements to the array
	        numbers[0] = 1;
	        numbers[1] = 2;
	        numbers[2] = 3;

	        // Display the elements in the array
	        System.out.println("Elements in the collection:");
	        for (int i = 0; i < numbers.length; i++) {
	            System.out.println(numbers[i]);
	        }

	        // Check if the collection contains a specific element
	        int searchNumber = 2;
	        boolean found = false;
	        for (int i = 0; i < numbers.length; i++) {
	            if (numbers[i] == searchNumber) {
	                found = true;
	                break;
	            }
	        }
	        if (found) {
	            System.out.println(searchNumber + " is in the collection.");
	        } else {
	            System.out.println(searchNumber + " is not in the collection.");
	        }

	        // Remove an element (set it to 0)
	        int numberToRemove = 3;
	        for (int i = 0; i < numbers.length; i++) {
	            if (numbers[i] == numberToRemove) {
	                numbers[i] = 0;
	                System.out.println(numberToRemove + " removed from the collection.");
	                break;
	            }
	        }

	        // Display the updated collection
	        System.out.println("Updated elements in the collection:");
	        for (int i = 0; i < numbers.length; i++) {
	            System.out.println(numbers[i]);
	        }

	        // Get the size of the collection
	        int size = numbers.length;
	        System.out.println("Size of the collection: " + size);
	    }

}
