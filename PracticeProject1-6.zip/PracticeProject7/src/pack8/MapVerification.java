package pack8;
import java.util.*;

public class MapVerification {

	public static void main(String[] args) {
		// Create a HashMap
        Map<String, Integer> map = new HashMap<>();

        // Add key value pairs to the map
        map.put("Sam", 25);
        map.put("Virat", 30);
        map.put("Charlie", 22);

        // Verify the implementation by retrieving values
        System.out.println("Age of Sam: " + map.get("Sam"));
        System.out.println("Age of Virat: " + map.get("Virat"));
        System.out.println("Age of Charlie: " + map.get("Charlie"));

        // Verify the implementation by checking if a key exists
        System.out.println("Is Sam in the map? " + map.containsKey("Sam"));
        System.out.println("Is David in the map? " + map.containsKey("David"));

        // Verify the implementation by removing a key value pair
        map.remove("Charlie");
        System.out.println("Age of Charlie after removal: " + map.get("Charlie"));
    }
	
}
