package com.simplilearn.demo;

import org.testng.annotations.Test;

public class GroupTest {
	WebDriver driver=null;
	
  @Test(groups="Chrome")
  public void launchChrome() {
	  
	  System.setProperty("C:\\Phase5Installation\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe" );
	  driver =new ChromeDriver();
	  driver.get("https://www.facebook.com/");
	  
	  try {
		Thread.sleep(3000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	  
  }
  
  @Test(groups="Chrome",dependsOnMethods = {"launchChrome"} )
  public  void loginWithChrome() {
	  

	  driver.findElement(By.id("email")).sendKeys("Nikunj@gmail.com");
	  driver.findElement(By.id("pass")).sendKeys("Nikunj@123");
	  driver.findElement(By.name("login")).click();
	  //driver.close();
	  
  }
  
