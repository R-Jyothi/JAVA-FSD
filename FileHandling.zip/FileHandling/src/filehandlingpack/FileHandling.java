package filehandlingpack;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileHandling {

	public static void main(String[] args) {
		String filename="Exam.txt";
		//write a file
		try(BufferedWriter writer = new BufferedWriter(new FileWriter(filename))){
			writer.write("This is my first line");
			writer.newLine();
			writer.write("This is my second file");
			
		}catch(IOException e) {
			e.printStackTrace();
		}
		try(BufferedReader reader = new BufferedReader(new FileReader(filename))){
			String line;
			while((line=reader.readLine())!=null) {
				System.out.println(line);
				
			}
		}catch(IOException e) {
			e.printStackTrace();
		}
		
		
		try(BufferedWriter writer = new BufferedWriter(new FileWriter(filename))){
			writer.newLine();
			writer.write("This is appended line");
		}
		catch(IOException e) {
			e.printStackTrace();
		}

	}

}
