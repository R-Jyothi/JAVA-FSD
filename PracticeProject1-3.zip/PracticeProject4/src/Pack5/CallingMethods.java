package Pack5;


//calling methods in mathoperations
public class CallingMethods {
	
	//method to add two numbers and return the result
	public int add(int num1, int num2) {
		return num1+num2;
	}
	
	//method to subtract two numbers and return the result
	public int subtract(int num1, int num2) {
		return num1-num2;
	}

	public static void main(String[] args) {
		CallingMethods cal=new CallingMethods();
		
		//calling the add method
		int sum=cal.add(3, 9);
		System.out.println("sum of the two numbers :" +sum);
		
		//calling the subtract method
		int diff=cal.subtract(20,7);
		System.out.println("difference of the two numbers :" +diff);
		
		
		//calling the add method with different numbers
		int anothersum=cal.add(15, 8);
		System.out.println("sum of the another two numbers :" + anothersum);
		

	}

}
